from PyQt5.QtWidgets import (QMainWindow, QPushButton, QLabel, QAction, QFileDialog,
                         QMessageBox, QVBoxLayout, QWidget, QProgressBar, QDialog, QTextEdit, QHBoxLayout)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QPixmap
import h5py
import os
from datetime import datetime
from UI.informations import InformationWindow
from utils.hdf5_utils import load_metadata, save_metadata
class MainBar:
    def __init__(self, main_app):
        self.main_app = main_app

    def create_new_subject(self):
        """Creates a new subject file and opens information window"""
        if self.main_app.modified:
            reply = QMessageBox.question(
                self.main_app,
                'Unsaved Changes',
                'There are unsaved changes. Save before creating new subject?',
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel
            )
            if reply == QMessageBox.Save:
                self.main_app.save_subject_notsave()
            elif reply == QMessageBox.Cancel:
                return

        options = QFileDialog.Options()
        filename, _ = QFileDialog.getSaveFileName(
            self.main_app,
            "Create New Subject File",
            "",
            "HDF5 Files (*.h5 *.hdf5);;All Files (*)",
            options=options
        )

        if filename:
            if not filename.endswith(".h5") and not filename.endswith(".hdf5"):
                filename += ".h5"

            try:
                # Initialize basic file structure
                with h5py.File(filename, 'w') as f:
                    f.attrs['subject_created'] = True
                    f.attrs['creation_date'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    f.create_group('metadata')
                    f.create_group('trials')

                self.main_app.current_subject_file = filename
                self.main_app.modified = False
                self.main_app.save_subject_action.setEnabled(True)
                self.main_app.save_subject_as_action.setEnabled(True)
                self.main_app.show_metadata_action.setEnabled(True)

                self.main_app.statusBar().showMessage(f"New subject file created: {os.path.basename(filename)}")

                # Display information window to collect metadata
                self.main_app.info_window = InformationWindow(self.main_app, self.main_app.current_subject_file)
                self.main_app.info_window.info_submitted.connect(self.main_app.update_subject_metadata)

                def closeEvent(event):
                    self.main_app.save_subject_action.setEnabled(False)
                    self.main_app.save_subject_as_action.setEnabled(False)
                    self.main_app.show_metadata_action.setEnabled(False)
                    event.accept()

                self.main_app.info_window.closeEvent = closeEvent
                self.main_app.info_window.show()

            except Exception as e:
                self.main_app._show_error(f"Error creating subject file: {str(e)}")

    # Ajoutez les autres méthodes de MainBar ici


    # Ajoutez les autres méthodes de MainBar ici


    def load_existing_subject(self, review=False):
        """Load an existing subject file"""
        if self.main_app.modified:
            reply = QMessageBox.question(self.main_app, 'Unsaved Changes',
                                        'There are unsaved changes. Save before loading a new subject?',
                                        QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            if reply == QMessageBox.Save:
                self.main_app.save_subject_notsave()
            elif reply == QMessageBox.Cancel:
                return

        options = QFileDialog.Options()
        filename, _ = QFileDialog.getOpenFileName(
            self.main_app,
            "Open Subject File",
            "",
            "HDF5 Files (*.h5 *.hdf5);;All Files (*)",
            options=options
        )

        if filename:
            try:
                with h5py.File(filename, 'r') as f:
                    if 'subject_created' in f.attrs:
                        # Load metadata
                        data, image_path = load_metadata(filename)

                        # Update the current file and UI
                        self.main_app.current_subject_file = filename
                        self.main_app.modified = False
                        self.main_app.save_subject_action.setEnabled(True)
                        self.main_app.save_subject_as_action.setEnabled(True)
                        self.main_app.show_metadata_action.setEnabled(True)

                        # Update the status bar
                        self.main_app.statusBar().showMessage(f"Loaded subject file: {os.path.basename(filename)}")

                        if 'trials' in f:
                            pass

                        self.main_app.info_window = InformationWindow(self.main_app, self.main_app.current_subject_file, review)
                        self.main_app.info_window.info_submitted.connect(self.main_app.update_subject_metadata)

                        def closeEvent(event):
                            self.main_app.save_subject_action.setEnabled(False)
                            self.main_app.save_subject_as_action.setEnabled(False)
                            self.main_app.show_metadata_action.setEnabled(False)
                            event.accept()

                        self.main_app.info_window.closeEvent = closeEvent
                        self.main_app.info_window.show()

                    else:
                        self.main_app._show_error("Not a valid subject file. Missing required attributes.")
                        return

            except Exception as e:
                self.main_app._show_error(f"Error loading subject file: {str(e)}")
                return

    def save_subject(self):
        """Save the current subject file"""
        if not self.main_app.current_subject_file:
            return self.save_subject_as()
        else:
            self.main_app.info_window._collect_data()
        try:
            # Logic to save data to current file
            # This is a placeholder - your actual save logic might be more complex
            self.main_app.modified = False
            self.main_app.statusBar().showMessage(f"Saved to {os.path.basename(self.main_app.current_subject_file)}")
            return True
        except Exception as e:
            self.main_app._show_error(f"Error saving subject: {str(e)}")
            return False

    def save_subject_notsave(self):
        """Save the current subject file"""
        if not self.main_app.current_subject_file:
            return self.save_subject_as()
        else:
            self.main_app.info_window._collect_data_notsave()
        try:
            self.main_app.modified = False
            self.main_app.statusBar().showMessage(f"Saved to {os.path.basename(self.main_app.current_subject_file)}")
            return True
        except Exception as e:
            self.main_app._show_error(f"Error saving subject: {str(e)}")
            return False

    def save_subject_as(self):
        """Save the subject file with a new name"""
        options = QFileDialog.Options()
        filename, _ = QFileDialog.getSaveFileName(
            self.main_app,
            "Save Subject As",
            "",
            "HDF5 Files (*.h5 *.hdf5);;All Files (*)",
            options=options
        )

        if filename:
            if not filename.endswith(".h5") and not filename.endswith(".hdf5"):
                filename += ".h5"

            self.main_app.current_subject_file = filename
            return self.save_subject()
        return False

    def save_subject_as_notsave(self):
        """Save the subject file with a new name"""
        options = QFileDialog.Options()
        filename, _ = QFileDialog.getSaveFileName(
            self.main_app,
            "Save Subject As",
            "",
            "HDF5 Files (*.h5 *.hdf5);;All Files (*)",
            options=options
        )

        if filename:
            if not filename.endswith(".h5") and not filename.endswith(".hdf5"):
                filename += ".h5"

            self.main_app.current_subject_file = filename
            return self.save_subject_notsave()
        return False

    def show_metadata(self):
        """Display metadata of the current subject"""
        if not self.main_app.current_subject_file:
            QMessageBox.information(self.main_app, "No Subject", "Please open or create a subject first.")
            return

        try:
            # Load metadata from the current file
            data, image_path = load_metadata(self.main_app.current_subject_file)

            if not data:
                QMessageBox.information(self.main_app, "No Metadata", "No metadata available for this subject.")
                return

            # Create a formatted text to display metadata
            metadata_text = "<h2>Subject Metadata</h2>"
            metadata_text += "<table style='border-collapse: collapse; width: 100%;'>"

            # Personal information section
            metadata_text += "<tr><th colspan='2' style='background-color: #f0f0f0; padding: 8px; text-align: left; border-bottom: 1px solid #ddd;'>Personal Information</th></tr>"

            # Add personal info fields if they exist
            for field in ["Name", "Last Name", "Age", "Weight", "Size"]:
                if field in data:
                    metadata_text += f"<tr><td style='padding: 8px; border-bottom: 1px solid #ddd;'><b>{field}</b></td>"
                    metadata_text += f"<td style='padding: 8px; border-bottom: 1px solid #ddd;'>{data[field]}</td></tr>"

            metadata_text += "<tr><th colspan='2' style='background-color: #f0f0f0; padding: 8px; text-align: left; border-bottom: 1px solid #ddd;'>Anthropometric Measurements</th></tr>"

            for field in ["Thigh length (cm)", "Shank length (cm)", "Upperarm length (cm)", "Forearm length (cm)"]:
                if field in data:
                    metadata_text += f"<tr><td style='padding: 8px; border-bottom: 1px solid #ddd;'><b>{field}</b></td>"
                    metadata_text += f"<td style='padding: 8px; border-bottom: 1px solid #ddd;'>{data[field]}</td></tr>"

            metadata_text += "<tr><th colspan='2' style='background-color: #f0f0f0; padding: 8px; text-align: left; border-bottom: 1px solid #ddd;'>Collection Information</th></tr>"

            if "collection_date" in data:
                metadata_text += f"<tr><td style='padding: 8px; border-bottom: 1px solid #ddd;'><b>Collection Date</b></td>"
                metadata_text += f"<td style='padding: 8px; border-bottom: 1px solid #ddd;'>{data['collection_date']}</td></tr>"

            # Add experimenter name if it exists
            if "experimenter_name" in data:
                metadata_text += f"<tr><td style='padding: 8px; border-bottom: 1px solid #ddd;'><b>Experimenter</b></td>"
                metadata_text += f"<td style='padding: 8px; border-bottom: 1px solid #ddd;'>{data['experimenter_name']}</td></tr>"

            metadata_text += "</table>"

            # Description if it exists
            if "Description" in data and data["Description"]:
                metadata_text += f"<h3>Description</h3><p>{data['Description']}</p>"

            # Display image if it exists
            if image_path and os.path.exists(image_path):
                # Create a dialog to display the metadata
                dialog = QDialog(self.main_app)
                dialog.setWindowTitle("Subject Metadata")
                dialog.setMinimumWidth(600)

                layout = QVBoxLayout(dialog)

                # Image at the top
                image_label = QLabel()
                pixmap = QPixmap(image_path)
                if not pixmap.isNull():
                    scaled_pixmap = pixmap.scaled(300, 300, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    image_label.setPixmap(scaled_pixmap)
                    image_label.setAlignment(Qt.AlignCenter)
                    layout.addWidget(image_label)

                # Metadata below
                metadata_browser = QTextEdit()
                metadata_browser.setReadOnly(True)
                metadata_browser.setHtml(metadata_text)
                layout.addWidget(metadata_browser)

                # Button at the bottom
                button_box = QWidget()
                button_layout = QHBoxLayout(button_box)
                close_button = QPushButton("Close")
                close_button.clicked.connect(dialog.accept)
                button_layout.addStretch()
                button_layout.addWidget(close_button)

                layout.addWidget(button_box)

                dialog.exec_()
            else:
                # Just show the metadata without an image
                metadata_dialog = QMessageBox()
                metadata_dialog.setWindowTitle("Subject Metadata")
                metadata_dialog.setTextFormat(Qt.RichText)
                metadata_dialog.setText(metadata_text)
                metadata_dialog.setStandardButtons(QMessageBox.Ok)
                metadata_dialog.exec_()

        except Exception as e:
            self.main_app._show_error(f"Error displaying metadata: {str(e)}")

    def show_about_dialog(self):
        """Show information about the software"""
        about_text = """
        <h1>Data Monitoring Software</h1>
        <p>Version 2.5.0</p>
        <p>An advanced monitoring tool for exoskeleton data.</p>
        <p>© 2025 Advanced Exoskeleton Research Laboratory</p>
        <p>For help and documentation, please visit our website or contact support.</p>
        """

        QMessageBox.about(self.main_app, "About Data Monitoring Software", about_text)

    def _create_action(self, text, slot=None, shortcut=None, icon=None, tip=None, checkable=False):
        """Create a QAction with the given properties"""
        action = QAction(text, self.main_app)
        if icon:
            action.setIcon(icon)
        if shortcut:
            action.setShortcut(shortcut)
        if tip:
            action.setToolTip(tip)
            action.setStatusTip(tip)
        if slot:
            action.triggered.connect(slot)
        if checkable:
            action.setCheckable(True)
        return action

    def _create_menubar(self):
        """Create the application menu bar"""
        menubar = self.main_app.menuBar()

        # File menu
        file_menu = menubar.addMenu('&File')

        # File menu actions
        create_subject_action = self._create_action(
            "&Create new subject",
            lambda: self.create_new_subject(),
            "Ctrl+N"
        )

        load_subject_action = self._create_action(
            "&Load existing subject",
            lambda: self.load_existing_subject(),
            "Ctrl+O",
            tip="Load an existing subject file"
        )

        self.save_subject_action = self._create_action(
            "&Save subject",
            lambda: self.save_subject_notsave(),
            "Ctrl+S",
            tip="Save the current subject"
        )

        self.save_subject_as_action = self._create_action(
            "Save subject &as...",
            lambda: self.save_subject_as_notsave(),
            "Ctrl+Shift+S",
            tip="Save the subject with a new name"
        )

        self.show_metadata_action = self._create_action(
            "&Show metadata",
            lambda: self.show_metadata(),
            "Ctrl+M",
            tip="Display subject metadata"
        )

        self.load_existing_trial = self._create_action(
            "Load existing trial",
            lambda: self.load_existing_subject(True),
            "Ctrl+F",
            tip="Load an existing trial"
        )

        self.Save_current_trial = self._create_action(
            "&Save current trial",
            lambda: self.show_metadata(),
            "Ctrl+M",
            tip="Save a current trial"
        )

        self.Save_current_trial_as = self._create_action(
            "&Save current trial as...",
            lambda: self.show_metadata(),
            "Ctrl+M",
            tip="Save current trial in a new file"
        )

        self.Save_current_plotas_image = self._create_action(
            "&Save current plotas image",
            lambda: self.show_metadata(),
            "Ctrl+M",
            tip="Save current plotas image"
        )

        exit_action = self._create_action(
            "E&xit",
            lambda: self.main_app.close,
            "Alt+F4",
            tip="Exit the application"
        )

        # Add actions to file menu
        file_menu.addAction(create_subject_action)
        file_menu.addAction(load_subject_action)
        file_menu.addSeparator()
        file_menu.addAction(self.save_subject_action)
        file_menu.addAction(self.save_subject_as_action)
        file_menu.addSeparator()
        file_menu.addAction(self.load_existing_trial)
        file_menu.addAction(self.Save_current_trial)
        file_menu.addAction(self.Save_current_trial_as)
        file_menu.addAction(self.Save_current_plotas_image)
        file_menu.addSeparator()
        file_menu.addAction(self.show_metadata_action)
        file_menu.addSeparator()
        file_menu.addAction(exit_action)

        # Help menu
        help_menu = menubar.addMenu('&Help')

        # Help menu actions
        about_action = self._create_action(
            "&About",
            lambda: self.show_about_dialog(),
            tip="About the application"
        )

        # Add actions to help menu
        help_menu.addAction(about_action)

        # Initially disable actions that require an open file
        self.Save_current_trial.setEnabled(False)
        self.Save_current_trial_as.setEnabled(False)
        self.Save_current_plotas_image.setEnabled(False)

        self.save_subject_action.setEnabled(False)
        self.save_subject_as_action.setEnabled(False)
        self.show_metadata_action.setEnabled(False)
